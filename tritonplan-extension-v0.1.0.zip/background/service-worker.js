// ../shared/src/time.ts
function parse12h(s) {
  const m = s.trim().match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
  if (!m) return null;
  let h = Number(m[1]);
  const min = Number(m[2]);
  const ampm = m[3].toUpperCase();
  if (h === 12) h = 0;
  if (ampm === "PM") h += 12;
  return `${String(h).padStart(2, "0")}:${String(min).padStart(2, "0")}`;
}

// src/parser/parse-sched.ts
var TBA_SCHED = "Schedule Not Defined";
var DAY_MAP = {
  M: "Mon",
  Tu: "Tue",
  W: "Wed",
  Th: "Thu",
  F: "Fri",
  Sa: "Sat",
  Su: "Sun"
};
var TIME = "\\d{1,2}:\\d{2}\\s*[AP]M";
var TIME_RANGE = new RegExp(`(${TIME})\\s*-\\s*(${TIME})`, "i");
var FINAL_RE = new RegExp(
  `^Final Examination\\s+(\\d{1,2})/(\\d{1,2})/(\\d{4})\\s+(${TIME})\\s*-\\s*(${TIME})\\s*(.*)$`,
  "i"
);
function parseDays(daysPart) {
  return daysPart.split(",").map((t) => t.trim()).filter(Boolean).map((tok) => DAY_MAP[tok]).filter((d) => Boolean(d));
}
function splitLocation(location) {
  const idx = location.lastIndexOf(" Room ");
  if (idx === -1) return { building: location.trim() || void 0 };
  return {
    building: location.slice(0, idx).trim() || void 0,
    room: location.slice(idx + " Room ".length).trim() || void 0
  };
}
function parseMeetingLine(line) {
  const trimmed = line.trim();
  if (!trimmed) return null;
  let head = trimmed;
  let location;
  const atIdx = trimmed.indexOf(" @ ");
  if (atIdx !== -1) {
    head = trimmed.slice(0, atIdx).trim();
    location = trimmed.slice(atIdx + 3).trim();
  }
  const tm = head.match(TIME_RANGE);
  if (!tm) return null;
  const start = parse12h(tm[1]);
  const end = parse12h(tm[2]);
  if (!start || !end) return null;
  const daysPart = head.slice(0, tm.index).trim();
  const modality = head.slice((tm.index ?? 0) + tm[0].length).trim();
  const days = parseDays(daysPart);
  const loc = location ? splitLocation(location) : {};
  return {
    days,
    start,
    end,
    modality: modality || "Unknown",
    building: loc.building,
    room: loc.room,
    location
  };
}
function parseFinalLine(line) {
  const m = line.trim().match(FINAL_RE);
  if (!m) return null;
  const [, mm, dd, yyyy, s, e, modality] = m;
  const start = parse12h(s);
  const end = parse12h(e);
  if (!start || !end) return null;
  const date = `${yyyy}-${mm.padStart(2, "0")}-${dd.padStart(2, "0")}`;
  return { date, start, end, modality: modality?.trim() || void 0 };
}
function parseSched(sched) {
  const result = { meetings: [], unscheduled: false, unparsedLines: [] };
  if (!sched || !sched.trim() || sched.trim() === TBA_SCHED) {
    result.unscheduled = true;
    return result;
  }
  for (const rawLine of sched.split("\n")) {
    const line = rawLine.trim();
    if (!line) continue;
    if (/^Final Examination/i.test(line)) {
      const f = parseFinalLine(line);
      if (f) result.final = f;
      else result.unparsedLines.push(line);
      continue;
    }
    const meeting = parseMeetingLine(line);
    if (meeting) result.meetings.push(meeting);
    else result.unparsedLines.push(line);
  }
  if (result.meetings.length === 0 && !result.final && result.unparsedLines.length === 0) {
    result.unscheduled = true;
  }
  return result;
}

// src/parser/normalize.ts
var PERIOD_SEASON = {
  // Grounded: AcPeriod "2" = Fall (captured BeginDate 2026-09-24). Others TBD as captured.
  "2": "Fall"
};
function termFromRow(year, period) {
  const season = PERIOD_SEASON[period];
  const label = season ? `${season} ${year}` : `Period ${period} ${year}`;
  return { year, period, label };
}
var TYPE_ORDER = { LE: 0, SE: 1, DI: 2, LA: 3, ST: 4, IN: 5 };
function typeRank(t) {
  return TYPE_ORDER[t] ?? 9;
}
function toNum(s) {
  if (s == null || s === "") return void 0;
  const n = Number(s);
  return Number.isFinite(n) ? n : void 0;
}
function cleanEmail(raw) {
  if (!raw) return void 0;
  return raw.replace(/^mailto:\s*/i, "").trim().toLowerCase() || void 0;
}
function rowToComponent(row) {
  const parsed = parseSched(row.Sched);
  return {
    id: row.EventID,
    type: row.TeachingMethod,
    typeText: row.TeachingMethod_Text,
    sectionCode: row.EventAbbr,
    instructors: row.InstructorName ? [row.InstructorName] : [],
    instructorEmails: cleanEmail(row.InstructorEmail) ? [cleanEmail(row.InstructorEmail)] : void 0,
    meetings: parsed.meetings,
    unscheduled: parsed.unscheduled,
    beginDate: row.BeginDate,
    endDate: row.EndDate,
    rawSched: row.Sched
  };
}
function packageFinal(components, rows) {
  for (const c of components) {
    if (c.type === "LE") {
      const row = rows.find((r) => r.EventID === c.id);
      if (row) {
        const f = parseSched(row.Sched).final;
        if (f) return f;
      }
    }
  }
  for (const row of rows) {
    const f = parseSched(row.Sched).final;
    if (f) return f;
  }
  return void 0;
}
function pkgCode(text, fallback) {
  if (!text) return fallback;
  const m = text.match(/\(([^)]+)\)\s*$/);
  return m ? m[1] : text;
}
function normalizeSections(rows, meta) {
  if (rows.length === 0) {
    throw new Error("normalizeSections: no rows");
  }
  const first = rows[0];
  const term = termFromRow(first.AcYear, first.AcPeriod);
  const byPkg = /* @__PURE__ */ new Map();
  for (const row of rows) {
    const arr = byPkg.get(row.EventPkgOtjid);
    if (arr) arr.push(row);
    else byPkg.set(row.EventPkgOtjid, [row]);
  }
  const options = [];
  for (const [pkgId, pkgRows] of byPkg) {
    const seen = /* @__PURE__ */ new Set();
    const components = [];
    for (const row of pkgRows) {
      if (seen.has(row.EventID)) continue;
      seen.add(row.EventID);
      components.push(rowToComponent(row));
    }
    components.sort((a, b) => typeRank(a.type) - typeRank(b.type) || a.sectionCode.localeCompare(b.sectionCode));
    const sample = pkgRows[0];
    options.push({
      id: pkgId,
      code: pkgCode(sample.EventPkgText, pkgId),
      enrollCode: sample.EventPkgDisplayID ?? pkgId,
      limit: toNum(sample.EventPkgLimit),
      seatsAvailable: toNum(sample.EventPkgSeatsAvailable),
      waitlist: typeof sample.EventPkgNumOnWaitl === "number" ? sample.EventPkgNumOnWaitl : void 0,
      status: sample.EventPkgStatusText || void 0,
      components,
      final: packageFinal(components, pkgRows)
    });
  }
  options.sort((a, b) => a.code.localeCompare(b.code));
  const [subject, number] = splitCourseCode(meta.courseCode);
  return {
    id: `${meta.courseCode}|${term.year}|${term.period}`,
    moduleId: first.ModuleID,
    subject,
    number,
    courseCode: meta.courseCode,
    title: meta.title,
    term,
    units: meta.units,
    academicLevel: meta.academicLevel,
    department: meta.department,
    options
  };
}
function splitCourseCode(code) {
  const m = code.match(/^([A-Za-z]+)-?(\w+)$/);
  if (!m) return [code, ""];
  return [m[1], m[2]];
}

// src/lib/extract-odata.ts
function extractODataCollections(body) {
  if (!body) return [];
  const trimmed = body.trimStart();
  if (trimmed.startsWith("{")) {
    try {
      const obj = JSON.parse(body);
      if (obj && Array.isArray(obj.value)) return [obj];
    } catch {
    }
  }
  const out = [];
  let idx = 0;
  for (; ; ) {
    const start = body.indexOf('{"@odata.context"', idx);
    if (start === -1) break;
    const end = matchBrace(body, start);
    if (end === -1) break;
    try {
      const obj = JSON.parse(body.slice(start, end + 1));
      if (obj && Array.isArray(obj.value)) out.push(obj);
    } catch {
    }
    idx = end + 1;
  }
  return out;
}
function matchBrace(s, start) {
  let depth = 0;
  let inStr = false;
  let esc = false;
  for (let i = start; i < s.length; i++) {
    const ch = s[i];
    if (inStr) {
      if (esc) esc = false;
      else if (ch === "\\") esc = true;
      else if (ch === '"') inStr = false;
    } else if (ch === '"') inStr = true;
    else if (ch === "{") depth++;
    else if (ch === "}") {
      depth--;
      if (depth === 0) return i;
    }
  }
  return -1;
}
function looksLikeSectionRow(v) {
  return !!v && typeof v === "object" && "EventPkgOtjid" in v && "Sched" in v;
}
function looksLikeModuleRow(v) {
  return !!v && typeof v === "object" && "CourseAbbr" in v && "ModuleID" in v && "CourseTitle" in v;
}
function classifyCapture(body) {
  const moduleRows = [];
  const sectionRows = [];
  for (const coll of extractODataCollections(body)) {
    const first = coll.value?.[0];
    if (looksLikeSectionRow(first)) sectionRows.push(...coll.value);
    else if (looksLikeModuleRow(first)) moduleRows.push(...coll.value);
  }
  return { moduleRows, sectionRows };
}

// src/lib/capture-to-courses.ts
function creditsToUnits(s) {
  if (!s) return void 0;
  const n = parseFloat(s);
  return Number.isFinite(n) ? n : void 0;
}
function courseCodeFromSections(rows) {
  for (const r of rows) {
    const m = r.EventPkgText?.match(/^([A-Za-z]+-?\w+)\s*\(/);
    if (m) return m[1];
  }
  return void 0;
}
var CaptureStore = class _CaptureStore {
  modules = /* @__PURE__ */ new Map();
  sections = /* @__PURE__ */ new Map();
  /** Ingest one captured OData response body (plain or $batch). Returns true if anything new. */
  ingestBody(body) {
    const { moduleRows, sectionRows } = classifyCapture(body);
    let changed = false;
    for (const m of moduleRows) {
      this.modules.set(m.ModuleID, m);
      changed = true;
    }
    if (sectionRows.length) {
      const byModule = /* @__PURE__ */ new Map();
      for (const r of sectionRows) {
        const arr = byModule.get(r.ModuleID);
        if (arr) arr.push(r);
        else byModule.set(r.ModuleID, [r]);
      }
      for (const [moduleId, rows] of byModule) {
        this.sections.set(moduleId, rows);
        changed = true;
      }
    }
    return changed;
  }
  metaFor(moduleId, rows) {
    const mod = this.modules.get(moduleId);
    if (mod) {
      return {
        courseCode: mod.CourseAbbr,
        title: mod.CourseTitle,
        units: creditsToUnits(mod.CreditsDisplay),
        academicLevel: mod.AcademicLevel,
        department: mod.DepartmentText
      };
    }
    const code = courseCodeFromSections(rows);
    if (code) return { courseCode: code, title: code };
    return null;
  }
  /** Build CourseOffering[] for every module we have sections for. */
  toCourses() {
    const out = [];
    for (const [moduleId, rows] of this.sections) {
      if (!rows.length) continue;
      const meta = this.metaFor(moduleId, rows);
      if (!meta) continue;
      try {
        out.push(normalizeSections(rows, meta));
      } catch {
      }
    }
    out.sort((a, b) => a.courseCode.localeCompare(b.courseCode));
    return out;
  }
  serialize() {
    return {
      modules: Object.fromEntries(this.modules),
      sections: Object.fromEntries(this.sections)
    };
  }
  static deserialize(data) {
    const store = new _CaptureStore();
    if (data?.modules) for (const [k, v] of Object.entries(data.modules)) store.modules.set(k, v);
    if (data?.sections) for (const [k, v] of Object.entries(data.sections)) store.sections.set(k, v);
    return store;
  }
};

// src/config.ts
var PLANNER_URL = "https://hfjddjksaj.github.io/tritonplan/";
var PLANNER_MATCH = "https://hfjddjksaj.github.io/tritonplan/*";
var MSG = {
  /** relay → SW: one captured OData body to ingest + persist. */
  INGEST: "tp:ingest",
  /** any → SW: return the captured CourseOffering[]. */
  GET_COURSES: "tp:get-courses",
  /** tss-inject → SW: student clicked "+ TritonPlan" on a section. */
  PLAN_ADD: "tp:plan-add",
  /** popup → SW: open/focus the planner tab. */
  OPEN_PLANNER: "tp:open-planner",
  /** planner-bridge → SW: atomically read+clear queued plan-adds. */
  DRAIN_PLAN_ADDS: "tp:drain-plan-adds",
  /** SW → planner-bridge (via tabs.sendMessage): re-push courses + queued plan-adds. */
  FLUSH: "tp:flush"
};

// src/background/service-worker.ts
var STORE_KEY = "tp:store";
var QUEUE_KEY = "tp:pendingPlanAdds";
var storePromise = null;
async function getStore() {
  if (!storePromise) {
    storePromise = (async () => {
      const data = await chrome.storage.local.get(STORE_KEY);
      return CaptureStore.deserialize(data?.[STORE_KEY]);
    })();
  }
  return storePromise;
}
async function persist(store) {
  await chrome.storage.local.set({ [STORE_KEY]: store.serialize() });
}
async function enqueuePlanAdd(intent) {
  const data = await chrome.storage.local.get(QUEUE_KEY);
  const queue = Array.isArray(data?.[QUEUE_KEY]) ? data[QUEUE_KEY] : [];
  queue.push(intent);
  await chrome.storage.local.set({ [QUEUE_KEY]: queue });
}
async function drainPlanAdds() {
  const data = await chrome.storage.local.get(QUEUE_KEY);
  const queue = Array.isArray(data?.[QUEUE_KEY]) ? data[QUEUE_KEY] : [];
  if (queue.length) await chrome.storage.local.set({ [QUEUE_KEY]: [] });
  return queue;
}
async function openOrFocusPlanner() {
  let tabs = [];
  try {
    tabs = await chrome.tabs.query({ url: PLANNER_MATCH });
  } catch {
    tabs = [];
  }
  const existing = tabs.find((t) => t.id != null);
  if (existing && existing.id != null) {
    try {
      await chrome.tabs.update(existing.id, { active: true });
      if (existing.windowId != null) {
        await chrome.windows.update(existing.windowId, { focused: true });
      }
    } catch {
    }
    return existing;
  }
  try {
    return await chrome.tabs.create({ url: PLANNER_URL });
  } catch {
    return void 0;
  }
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || typeof msg !== "object") return false;
  switch (msg.type) {
    case MSG.INGEST: {
      const body = typeof msg.body === "string" ? msg.body : "";
      (async () => {
        try {
          if (body) {
            const store = await getStore();
            if (store.ingestBody(body)) await persist(store);
          }
          sendResponse({ ok: true });
        } catch {
          sendResponse({ ok: false });
        }
      })();
      return true;
    }
    case MSG.GET_COURSES: {
      (async () => {
        try {
          const store = await getStore();
          const courses = store.toCourses();
          sendResponse(courses);
        } catch {
          sendResponse([]);
        }
      })();
      return true;
    }
    case MSG.PLAN_ADD: {
      const course = msg.course;
      const selectedOptionId = typeof msg.selectedOptionId === "string" ? msg.selectedOptionId : "";
      (async () => {
        try {
          if (course && selectedOptionId) {
            await enqueuePlanAdd({ course, selectedOptionId });
            const tab = await openOrFocusPlanner();
            if (tab?.id != null) {
              try {
                await chrome.tabs.sendMessage(tab.id, { type: MSG.FLUSH });
              } catch {
              }
            }
            sendResponse({ ok: true });
          } else {
            sendResponse({ ok: false });
          }
        } catch {
          sendResponse({ ok: false });
        }
      })();
      return true;
    }
    case MSG.OPEN_PLANNER: {
      (async () => {
        await openOrFocusPlanner();
        sendResponse({ ok: true });
      })();
      return true;
    }
    case MSG.DRAIN_PLAN_ADDS: {
      (async () => {
        try {
          sendResponse(await drainPlanAdds());
        } catch {
          sendResponse([]);
        }
      })();
      return true;
    }
    default:
      return false;
  }
});
//# sourceMappingURL=service-worker.js.map
