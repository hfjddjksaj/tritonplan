"use strict";
(() => {
  // src/config.ts
  var MSG = {
    /** relay → SW: one captured OData body to ingest + persist. */
    INGEST: "tp:ingest",
    /** any → SW: return the captured CourseOffering[]. */
    GET_COURSES: "tp:get-courses",
    /** tss-inject → SW: student clicked "+ TritonPlan" on a section. */
    PLAN_ADD: "tp:plan-add",
    /** popup → SW: open/focus the planner tab. */
    OPEN_PLANNER: "tp:open-planner",
    /** planner-bridge → SW: atomically read+clear queued plan-adds. */
    DRAIN_PLAN_ADDS: "tp:drain-plan-adds",
    /** SW → planner-bridge (via tabs.sendMessage): re-push courses + queued plan-adds. */
    FLUSH: "tp:flush"
  };

  // src/popup/popup.ts
  function render(courses) {
    const list = document.getElementById("courses");
    if (!list) return;
    list.textContent = "";
    if (!courses.length) {
      const li = document.createElement("li");
      li.className = "empty";
      li.textContent = "Nothing captured yet \u2014 browse a course in TSS.";
      list.appendChild(li);
      return;
    }
    for (const c of courses) {
      const li = document.createElement("li");
      const code = document.createElement("span");
      code.className = "code";
      code.textContent = c.courseCode;
      const title = document.createElement("span");
      title.className = "title";
      title.textContent = c.title && c.title !== c.courseCode ? ` \u2014 ${c.title}` : "";
      li.appendChild(code);
      li.appendChild(title);
      list.appendChild(li);
    }
  }
  async function load() {
    try {
      const res = await chrome.runtime.sendMessage({ type: MSG.GET_COURSES });
      render(Array.isArray(res) ? res : []);
    } catch {
      render([]);
    }
  }
  document.getElementById("open")?.addEventListener("click", () => {
    void chrome.runtime.sendMessage({ type: MSG.OPEN_PLANNER });
    window.close();
  });
  void load();
})();
//# sourceMappingURL=popup.js.map
