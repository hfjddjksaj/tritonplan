"use strict";
(() => {
  // src/config.ts
  var PLANNER_ORIGIN = "https://hfjddjksaj.github.io";
  var BRIDGE_SOURCE = "triton-planner-extension";
  var BRIDGE_VERSION = 1;
  var MSG = {
    /** relay → SW: one captured OData body to ingest + persist. */
    INGEST: "tp:ingest",
    /** any → SW: return the captured CourseOffering[]. */
    GET_COURSES: "tp:get-courses",
    /** tss-inject → SW: student clicked "+ TritonPlan" on a section. */
    PLAN_ADD: "tp:plan-add",
    /** popup → SW: open/focus the planner tab. */
    OPEN_PLANNER: "tp:open-planner",
    /** planner-bridge → SW: atomically read+clear queued plan-adds. */
    DRAIN_PLAN_ADDS: "tp:drain-plan-adds",
    /** SW → planner-bridge (via tabs.sendMessage): re-push courses + queued plan-adds. */
    FLUSH: "tp:flush"
  };

  // src/content/planner-bridge.ts
  async function pushCourses() {
    try {
      const courses = await chrome.runtime.sendMessage({ type: MSG.GET_COURSES });
      if (!Array.isArray(courses)) return;
      window.postMessage(
        {
          source: BRIDGE_SOURCE,
          type: "courses",
          version: BRIDGE_VERSION,
          payload: courses
        },
        PLANNER_ORIGIN
      );
    } catch {
    }
  }
  async function flushPlanAdds() {
    try {
      const items = await chrome.runtime.sendMessage({ type: MSG.DRAIN_PLAN_ADDS });
      if (!Array.isArray(items)) return;
      for (const it of items) {
        if (!it || !it.course || typeof it.selectedOptionId !== "string") continue;
        window.postMessage(
          {
            source: BRIDGE_SOURCE,
            type: "plan-add",
            version: BRIDGE_VERSION,
            payload: { course: it.course, selectedOptionId: it.selectedOptionId }
          },
          PLANNER_ORIGIN
        );
      }
    } catch {
    }
  }
  async function syncAll() {
    await pushCourses();
    await flushPlanAdds();
  }
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === MSG.FLUSH) void syncAll();
  });
  void syncAll();
})();
//# sourceMappingURL=planner-bridge.js.map
