"use strict";
(() => {
  // src/config.ts
  var PRODUCT_NAME = "TritonPlan";
  var MSG = {
    /** relay → SW: one captured OData body to ingest + persist. */
    INGEST: "tp:ingest",
    /** any → SW: return the captured CourseOffering[]. */
    GET_COURSES: "tp:get-courses",
    /** tss-inject → SW: student clicked "+ TritonPlan" on a section. */
    PLAN_ADD: "tp:plan-add",
    /** popup → SW: open/focus the planner tab. */
    OPEN_PLANNER: "tp:open-planner",
    /** planner-bridge → SW: atomically read+clear queued plan-adds. */
    DRAIN_PLAN_ADDS: "tp:drain-plan-adds",
    /** SW → planner-bridge (via tabs.sendMessage): re-push courses + queued plan-adds. */
    FLUSH: "tp:flush"
  };

  // src/lib/tss-dom.ts
  function extractModuleRef(hashOrUrl) {
    if (!hashOrUrl) return null;
    const moduleId = matchKey(hashOrUrl, "ModuleID");
    if (!moduleId) return null;
    return {
      moduleId,
      academicYear: matchKey(hashOrUrl, "AcademicYear") ?? "",
      academicPeriod: matchKey(hashOrUrl, "AcademicPeriod") ?? ""
    };
  }
  function matchKey(s, key) {
    const re = new RegExp(`${key}=(?:'|%27)?([^'&,)%]+)`, "i");
    const m = s.match(re);
    return m ? m[1] : null;
  }
  function parsePackageLabel(text) {
    if (!text) return {};
    const m = text.match(/([A-Za-z]+-?\w+)\s*\(([^)]+)\)/);
    if (m) return { courseCode: m[1], packageCode: m[2].trim() };
    return {};
  }
  function parseEnrollCode(text) {
    if (!text) return null;
    const m = text.match(/\b([A-Z]{2}\d{6,})\b/);
    return m ? m[1] : null;
  }
  function findCourseByModuleId(courses, moduleId) {
    if (!moduleId) return null;
    for (const c of courses) if (c.moduleId === moduleId) return c;
    return null;
  }
  function resolveOption(course, card) {
    const ec = card.enrollCode?.trim();
    const pc = card.packageCode?.trim();
    if (ec) {
      for (const o of course.options) if (o.enrollCode === ec) return o;
      for (const o of course.options) if (o.id === ec) return o;
    }
    if (pc) {
      for (const o of course.options) if (o.code === pc) return o;
    }
    return null;
  }

  // src/content/tss-inject.ts
  var CARD_SELECTOR = ".socPkgBlock";
  var HEADER_SELECTORS = [".socPkgHeader", ".socPkgHeaderMain"];
  var ENROLL_CODE_SELECTOR = ".socPkgId";
  var PKG_NAME_SELECTOR = ".socPkgName";
  var INJECTED_ATTR = "data-tritonplan-injected";
  var BUTTON_LABEL = `+ ${PRODUCT_NAME}`;
  var cachedCourses = [];
  async function refreshCourses() {
    try {
      const res = await chrome.runtime.sendMessage({ type: MSG.GET_COURSES });
      if (Array.isArray(res)) cachedCourses = res;
    } catch {
    }
  }
  function readCard(card) {
    const idText = (card.querySelector(ENROLL_CODE_SELECTOR)?.textContent ?? "").trim();
    const nameText = (card.querySelector(PKG_NAME_SELECTOR)?.textContent ?? "").trim();
    const blockText = (card.textContent ?? "").replace(/\s+/g, " ").trim();
    const enrollCode = /^[A-Za-z]{2}\d{4,}$/.test(idText) ? idText : parseEnrollCode(blockText);
    const { packageCode } = parsePackageLabel(nameText || blockText);
    return { enrollCode, packageCode };
  }
  var STYLE_ID = "tritonplan-inject-style";
  function injectStyleOnce() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = [
      ".tp-plan-btn{margin-left:10px;padding:2px 10px;",
      'font:600 13px/18px "72","72full",Arial,Helvetica,sans-serif;',
      "color:#fff;background:#27367b;border:1px solid #27367b;border-radius:8px;",
      "cursor:pointer;vertical-align:middle;white-space:nowrap;transition:background .1s}",
      ".tp-plan-btn:hover{background:#1e2a63;border-color:#1e2a63}",
      ".tp-plan-btn:active{background:#18214f;border-color:#18214f}"
    ].join("");
    (document.head || document.documentElement).appendChild(style);
  }
  function makeButton(onClick) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "tp-plan-btn";
    btn.textContent = BUTTON_LABEL;
    btn.setAttribute("aria-label", BUTTON_LABEL);
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      onClick();
    });
    return btn;
  }
  function flash(btn, text, ok) {
    const prev = btn.textContent;
    btn.textContent = text;
    const c = ok ? "#2e7d32" : "#b23c3c";
    btn.style.background = c;
    btn.style.borderColor = c;
    btn.style.color = "#fff";
    setTimeout(() => {
      btn.textContent = prev;
      btn.style.background = "";
      btn.style.borderColor = "";
      btn.style.color = "";
    }, 1400);
  }
  async function onAddClick(header, btn) {
    const ref = extractModuleRef(location.hash || location.href);
    if (!ref) {
      flash(btn, "No course open", false);
      return;
    }
    if (!cachedCourses.length) await refreshCourses();
    const course = findCourseByModuleId(cachedCourses, ref.moduleId);
    if (!course) {
      await refreshCourses();
      const retry = findCourseByModuleId(cachedCourses, ref.moduleId);
      if (!retry) {
        flash(btn, "Browse first", false);
        return;
      }
      return finish(retry, header, btn);
    }
    return finish(course, header, btn);
  }
  async function finish(course, header, btn) {
    const card = readCard(header);
    const option = resolveOption(course, card);
    if (!option) {
      flash(btn, "Section not found", false);
      return;
    }
    try {
      await chrome.runtime.sendMessage({
        type: MSG.PLAN_ADD,
        course,
        selectedOptionId: option.id
      });
      flash(btn, "\u2713 Added", true);
    } catch {
      flash(btn, "Error", false);
    }
  }
  function injectTarget(card) {
    const header = HEADER_SELECTORS.map((s) => card.querySelector(s)).find(Boolean) ?? null;
    const nameEl = card.querySelector(PKG_NAME_SELECTOR);
    if (header && nameEl) {
      const row = Array.from(header.children).find((ch) => ch.contains(nameEl));
      if (row) return row;
    }
    return nameEl?.parentElement ?? header ?? card;
  }
  function scan() {
    let cards = [];
    try {
      cards = [...document.querySelectorAll(CARD_SELECTOR)];
    } catch {
      return;
    }
    if (cards.length) injectStyleOnce();
    for (const card of cards) {
      if (card.getAttribute(INJECTED_ATTR)) continue;
      card.setAttribute(INJECTED_ATTR, "1");
      try {
        const btn = makeButton(() => void onAddClick(card, btn));
        injectTarget(card).appendChild(btn);
      } catch {
      }
    }
  }
  function start() {
    let timer = null;
    const schedule = () => {
      if (timer) return;
      timer = setTimeout(() => {
        timer = null;
        scan();
      }, 400);
    };
    try {
      const obs = new MutationObserver(schedule);
      obs.observe(document.documentElement, { childList: true, subtree: true });
    } catch {
    }
    void refreshCourses();
    scan();
  }
  start();
})();
//# sourceMappingURL=tss-inject.js.map
