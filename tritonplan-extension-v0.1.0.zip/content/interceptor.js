"use strict";
(() => {
  // src/content/interceptor.ts
  var CHANNEL = "triton-planner:odata-capture";
  function isOData(url) {
    return typeof url === "string" && url.indexOf("/odata") !== -1;
  }
  function emit(url, status, body) {
    if (!body) return;
    const msg = { __tritonPlanner: true, channel: CHANNEL, url, status, body };
    window.postMessage(msg, window.location.origin);
  }
  function install() {
    const w = window;
    if (w.__tritonPlannerHooked) return;
    w.__tritonPlannerHooked = true;
    const originalFetch = window.fetch;
    window.fetch = function(...args) {
      const promise = originalFetch.apply(this, args);
      promise.then((res) => {
        try {
          if (res && isOData(res.url)) {
            res.clone().text().then((t) => emit(res.url, res.status, t)).catch(() => {
            });
          }
        } catch {
        }
      }).catch(() => {
      });
      return promise;
    };
    const OpenXHR = XMLHttpRequest.prototype.open;
    const SendXHR = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(method, url, ...rest) {
      this.__tpUrl = typeof url === "string" ? url : url.toString();
      return OpenXHR.call(this, method, url, ...rest);
    };
    XMLHttpRequest.prototype.send = function(...args) {
      this.addEventListener("load", () => {
        try {
          if (this.__tpUrl && isOData(this.__tpUrl)) {
            emit(this.__tpUrl, this.status, this.responseText || "");
          }
        } catch {
        }
      });
      return SendXHR.apply(this, args);
    };
  }
  install();
})();
//# sourceMappingURL=interceptor.js.map
