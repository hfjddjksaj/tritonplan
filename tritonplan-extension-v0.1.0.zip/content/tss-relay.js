"use strict";
(() => {
  // src/config.ts
  var ODATA_CAPTURE_CHANNEL = "triton-planner:odata-capture";
  var MSG = {
    /** relay → SW: one captured OData body to ingest + persist. */
    INGEST: "tp:ingest",
    /** any → SW: return the captured CourseOffering[]. */
    GET_COURSES: "tp:get-courses",
    /** tss-inject → SW: student clicked "+ TritonPlan" on a section. */
    PLAN_ADD: "tp:plan-add",
    /** popup → SW: open/focus the planner tab. */
    OPEN_PLANNER: "tp:open-planner",
    /** planner-bridge → SW: atomically read+clear queued plan-adds. */
    DRAIN_PLAN_ADDS: "tp:drain-plan-adds",
    /** SW → planner-bridge (via tabs.sendMessage): re-push courses + queued plan-adds. */
    FLUSH: "tp:flush"
  };

  // src/content/tss-relay.ts
  function isCaptureMessage(d) {
    return !!d && typeof d === "object" && d.__tritonPlanner === true && d.channel === ODATA_CAPTURE_CHANNEL && typeof d.body === "string";
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.origin !== window.location.origin) return;
    const data = event.data;
    if (!isCaptureMessage(data)) return;
    if (!data.body) return;
    try {
      void chrome.runtime.sendMessage({ type: MSG.INGEST, body: data.body }).catch(() => {
      });
    } catch {
    }
  });
})();
//# sourceMappingURL=tss-relay.js.map
